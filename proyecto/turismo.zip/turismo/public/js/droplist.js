/*
 * (c) Copyright 2018. BAL. All rigths reservated
 */

$(function () {
    $(".droplist .droplist-toggle").click(function () {
        $(this).parents(".droplist").children(".droplist-menu").slideToggle(300);
    });

    $(".navbar-toggler").click(function () {
        $(".navbar").find(".droplist-menu").slideUp(300);
    });
});
