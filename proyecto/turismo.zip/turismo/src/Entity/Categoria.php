<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\CategoriaRepository")
 * @ORM\Table(name="TBL_CATEGORIAS")
 */
class Categoria
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=25)
     */
    private $tipo;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Subcategoria", mappedBy="tipoCategoria", orphanRemoval=true, cascade={"persist"})
     */
    private $subcategorias;

    public function __construct()
    {
        $this->subcategorias = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTipo(): ?string
    {
        return $this->tipo;
    }

    public function setTipo(string $tipo): self
    {
        $this->tipo = $tipo;

        return $this;
    }

    /**
     * @return Collection|Subcategoria[]
     */
    public function getSubcategorias(): Collection
    {
        return $this->subcategorias;
    }

    public function addSubcategoria(Subcategoria $subcategoria): self
    {
        if (!$this->subcategorias->contains($subcategoria)) {
            $this->subcategorias[] = $subcategoria;
            $subcategoria->setTipoCategoria($this);
        }

        return $this;
    }

    public function removeSubcategoria(Subcategoria $subcategoria): self
    {
        if ($this->subcategorias->contains($subcategoria)) {
            $this->subcategorias->removeElement($subcategoria);
            // set the owning side to null (unless already changed)
            if ($subcategoria->getTipoCategoria() === $this) {
                $subcategoria->setTipoCategoria(null);
            }
        }

        return $this;
    }
}
