<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\ComentarioRepository")
 * @ORM\Table(name="TBL_COMENTARIOS")
 */
class Comentario
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="date")
     */
    private $fechaComentario;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $descripcionComentario;

    /**
     * @ORM\Column(type="smallint")
     */
    private $puntuacion;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Lugar", inversedBy="comentarios")
     */
    private $lugar;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Evento", inversedBy="comentarios")
     */
    private $evento;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Usuario")
     * @ORM\JoinColumn(nullable=false)
     */
    private $usuario;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getFechaComentario(): ?\DateTimeInterface
    {
        return $this->fechaComentario;
    }

    public function setFechaComentario(\DateTimeInterface $fechaComentario): self
    {
        $this->fechaComentario = $fechaComentario;

        return $this;
    }

    public function getDescripcionComentario(): ?string
    {
        return $this->descripcionComentario;
    }

    public function setDescripcionComentario(?string $descripcionComentario): self
    {
        $this->descripcionComentario = $descripcionComentario;

        return $this;
    }

    public function getPuntuacion(): ?int
    {
        return $this->puntuacion;
    }

    public function setPuntuacion(int $puntuacion): self
    {
        $this->puntuacion = $puntuacion;

        return $this;
    }

    public function getLugar(): ?Lugar
    {
        return $this->lugar;
    }

    public function setLugar(?Lugar $lugar): self
    {
        $this->lugar = $lugar;

        return $this;
    }

    public function getEvento(): ?Evento
    {
        return $this->evento;
    }

    public function setEvento(?Evento $evento): self
    {
        $this->evento = $evento;

        return $this;
    }

    public function getUsuario(): ?Usuario
    {
        return $this->usuario;
    }

    public function setUsuario(?Usuario $usuario): self
    {
        $this->usuario = $usuario;

        return $this;
    }
}
