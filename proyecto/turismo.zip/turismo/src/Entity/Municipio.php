<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\MunicipioRepository")
 * @ORM\Table(name="TBL_MUNICIPIOS")
 */
class Municipio
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=100)
     */
    private $nombre;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Distrito", inversedBy="municipios")
     * @ORM\JoinColumn(nullable=false)
     */
    private $distrito;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Lugar", mappedBy="municipio", orphanRemoval=true)
     */
    private $Lugares;

    public function __construct()
    {
        $this->Lugares = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNombre(): ?string
    {
        return $this->nombre;
    }

    public function setNombre(string $nombre): self
    {
        $this->nombre = $nombre;

        return $this;
    }

    public function __toString()
    {
        // TODO: Implement __toString() method.
        return $this->getNombre();
    }

    public function getDistrito(): ?Distrito
    {
        return $this->distrito;
    }

    public function setDistrito(?Distrito $distrito): self
    {
        $this->distrito = $distrito;

        return $this;
    }

    /**
     * @return Collection|Lugar[]
     */
    public function getLugares(): Collection
    {
        return $this->Lugares;
    }

    public function addLugare(Lugar $lugare): self
    {
        if (!$this->Lugares->contains($lugare)) {
            $this->Lugares[] = $lugare;
            $lugare->setMunicipio($this);
        }

        return $this;
    }

    public function removeLugare(Lugar $lugare): self
    {
        if ($this->Lugares->contains($lugare)) {
            $this->Lugares->removeElement($lugare);
            // set the owning side to null (unless already changed)
            if ($lugare->getMunicipio() === $this) {
                $lugare->setMunicipio(null);
            }
        }

        return $this;
    }
}
