<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\LugarRepository")
 * @ORM\Table(name="TBL_LUGARES")
 */
class Lugar
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=100)
     */
    private $nombre_lugar;

    /**
     * @ORM\Column(type="text")
     */
    private $descripcion_lugar;

    /**
     * @ORM\Column(type="integer")
     */
    private $tipo;

    /**
     * @ORM\Column(type="string", length=30)
     */
    private $nombre_calle;

    /**
    p * @ORM\Column(type="string", length=5)
     */
    private $numero_exterior;

    /**
     * @ORM\Column(type="string", length=50)
     */
    private $nombre_colonia;

    /**
     * @ORM\Column(type="string", length=5)
     */
    private $codigo_postal;

    /**
     * @ORM\Column(type="string", length=40, nullable=true)
     */
    private $nombre_localidad;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Foto", mappedBy="lugar", cascade={"persist"})
     */
    private $fotos;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Municipio", inversedBy="Lugares")
     * @ORM\JoinColumn(nullable=false)
     */
    private $municipio;

    public function __construct()
    {
        $this->fotos = new ArrayCollection();
        $this->platillos = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNombreLugar(): ?string
    {
        return $this->nombre_lugar;
    }

    public function setNombreLugar(string $nombre_lugar): self
    {
        $this->nombre_lugar = $nombre_lugar;

        return $this;
    }

    public function getDescripcionLugar(): ?string
    {
        return $this->descripcion_lugar;
    }

    public function setDescripcionLugar(string $descripcion_lugar): self
    {
        $this->descripcion_lugar = $descripcion_lugar;

        return $this;
    }

    public function getTipo(): ?int
    {
        return $this->tipo;
    }

    public function setTipo(int $tipo): self
    {
        $this->tipo = $tipo;

        return $this;
    }

    public function getNombreCalle(): ?string
    {
        return $this->nombre_calle;
    }

    public function setNombreCalle(string $nombre_calle): self
    {
        $this->nombre_calle = $nombre_calle;

        return $this;
    }

    public function getNumeroExterior(): ?string
    {
        return $this->numero_exterior;
    }

    public function setNumeroExterior(string $numero_exterior): self
    {
        $this->numero_exterior = $numero_exterior;

        return $this;
    }

    public function getNombreColonia(): ?string
    {
        return $this->nombre_colonia;
    }

    public function setNombreColonia(string $nombre_colonia): self
    {
        $this->nombre_colonia = $nombre_colonia;

        return $this;
    }

    public function getCodigoPostal(): ?string
    {
        return $this->codigo_postal;
    }

    public function setCodigoPostal(string $codigo_postal): self
    {
        $this->codigo_postal = $codigo_postal;

        return $this;
    }

    public function getNombreLocalidad(): ?string
    {
        return $this->nombre_localidad;
    }

    public function setNombreLocalidad(?string $nombre_localidad): self
    {
        $this->nombre_localidad = $nombre_localidad;

        return $this;
    }

    /**
     * @return Collection|Foto[]
     */
    public function getFotos(): Collection
    {
        return $this->fotos;
    }

    public function addFoto(Foto $foto): self
    {
        if (!$this->fotos->contains($foto)) {
            $this->fotos[] = $foto;
            $foto->setLugar($this);
        }

        return $this;
    }

    public function removeFoto(Foto $foto): self
    {
        if ($this->fotos->contains($foto)) {
            $this->fotos->removeElement($foto);
            // set the owning side to null (unless already changed)
            if ($foto->getLugar() === $this) {
                $foto->setLugar(null);
            }
        }

        return $this;
    }

    public function getMunicipio(): ?Municipio
    {
        return $this->municipio;
    }

    public function setMunicipio(?Municipio $municipio): self
    {
        $this->municipio = $municipio;

        return $this;
    }
}
