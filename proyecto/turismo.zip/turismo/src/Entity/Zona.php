<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\ZonaRepository")
 * @ORM\Table(name="TBL_ZONAS")
 */
class Zona
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=15)
     */
    private $nombre;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Distrito", mappedBy="zona", orphanRemoval=true)
     */
    private $distritos;

    public function __construct()
    {
        $this->distritos = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNombre(): ?string
    {
        return $this->nombre;
    }

    public function setNombre(string $nombre): self
    {
        $this->nombre = $nombre;

        return $this;
    }

    /**
     * @return Collection|Distrito[]
     */
    public function getDistritos(): Collection
    {
        return $this->distritos;
    }

    public function addDistrito(Distrito $distrito): self
    {
        if (!$this->distritos->contains($distrito)) {
            $this->distritos[] = $distrito;
            $distrito->setZona($this);
        }

        return $this;
    }

    public function removeDistrito(Distrito $distrito): self
    {
        if ($this->distritos->contains($distrito)) {
            $this->distritos->removeElement($distrito);
            // set the owning side to null (unless already changed)
            if ($distrito->getZona() === $this) {
                $distrito->setZona(null);
            }
        }

        return $this;
    }
}
