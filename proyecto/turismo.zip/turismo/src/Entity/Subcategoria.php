<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\SubcategoriaRepository")
 * @ORM\Table(name="TBL_SUBCATEGORIAS")
 */
class Subcategoria
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=25)
     */
    private $subtipo;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Categoria", inversedBy="subcategorias")
     * @ORM\JoinColumn(nullable=false)
     */
    private $tipoCategoria;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\Evento", inversedBy="subcategorias")
     */
    private $eventos;

    public function __construct()
    {
        $this->eventos = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getSubtipo(): ?string
    {
        return $this->subtipo;
    }

    public function setSubtipo(string $subtipo): self
    {
        $this->subtipo = $subtipo;

        return $this;
    }

    public function getTipoCategoria(): ?Categoria
    {
        return $this->tipoCategoria;
    }

    public function setTipoCategoria(?Categoria $tipoCategoria): self
    {
        $this->tipoCategoria = $tipoCategoria;

        return $this;
    }

    /**
     * @return Collection|Evento[]
     */
    public function getEventos(): Collection
    {
        return $this->eventos;
    }

    public function addEvento(Evento $evento): self
    {
        if (!$this->eventos->contains($evento)) {
            $this->eventos[] = $evento;
        }

        return $this;
    }

    public function removeEvento(Evento $evento): self
    {
        if ($this->eventos->contains($evento)) {
            $this->eventos->removeElement($evento);
        }

        return $this;
    }
}
