<?php

namespace App\Controller;

use App\Entity\Lugar;
use App\Form\LugarType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
/** @Route("/admin/lugares") */
class LugaresController extends AbstractController
{
    /**
     * @Route("/")
     */
    public function listar()
    {
        $repository = $this->getDoctrine()->getRepository(Lugar::class);
        $lugares = $repository->findAll();

        return $this->render('lugares/listarlugar.html.twig', [
            'lugares' => $lugares
        ]);
    }
    /** @Route("/agregar")
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     */
    public function agregar(Request $request){
        $lugar = new Lugar();
        $form = $this->createForm(LugarType::class, $lugar);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()){
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($lugar);
            $entityManager->flush();

            $this->addFlash('success','se agrego la lugar o monumento junto con sus fotos');

            return $this->redirect($request->getUri());
        }

        return $this->render('lugares/cruplugar.html.twig', [
            'form' => $form->createView()
        ]);
    }
}
