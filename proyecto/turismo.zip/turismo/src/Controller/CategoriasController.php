<?php

namespace App\Controller;

use App\Entity\Categoria;
use App\Form\CategoriaType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
/** @Route("/admin/categorias") */
class CategoriasController extends AbstractController
{
    /**
     * @Route("/")
     */
    public function listar()
    {
        $repository = $this->getDoctrine()->getRepository(Categoria::class);
        $categorias = $repository->findAll();

        return $this->render('categorias/listarcategorias.html.twig', [
            'categorias' => $categorias
        ]);
    }

    /** @Route("/agregar")
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     */
    public function agregar(Request $request){
        $categoria = new Categoria();
        $form = $this->createForm(CategoriaType::class, $categoria);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()){
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($categoria);
            $entityManager->flush();

            $this->addFlash('success','se agrego la categoria');

            return $this->redirect($request->getUri());
        }

        return $this->render('categorias/crupcategorias.html.twig', [
            'form' => $form->createView()
        ]);
    }
}
