<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

/**@Route("/")*/

class UsuariosController extends AbstractController
{
    /**
     * @Route("/")
     */

    public function index()
    {

        return $this->render('usuarios/index.html.twig', [
            'controller_name' => 'UsuariosController'
        ]);
    }
}
