<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class SubcategoriasController extends AbstractController
{
    /**
     * @Route("/subcategorias", name="subcategorias")
     */
    public function index()
    {
        return $this->render('subcategorias/index.html.twig', [
            'controller_name' => 'SubcategoriasController',
        ]);
    }
}
