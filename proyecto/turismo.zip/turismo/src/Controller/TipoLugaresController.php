<?php

namespace App\Controller;

use App\Entity\Lugar;
use App\Form\FiltrarType;
use App\Form\SubcategoriaType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
/**
 * @Route("/")
 */
class TipoLugaresController extends AbstractController
{
    /**
     * @Route("/restaurante")
     */
    public function restaurante(Request $request)
    {
        $repository = $this->getDoctrine()->getRepository(Lugar::class);
        $lugares = $repository->findBy([
           'tipo' => 0
        ]);
        $form = $this->createForm(FiltrarType::class);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()){
            $repository = $this->getDoctrine()->getRepository(Lugar::class);
            $lugares = $repository->findBy([
                'municipio' => $form->getData()['municipio']
            ]);
        }

        $pagina = $request->query->get('p', 1);
        $numPaginas = ceil(count($lugares) / 15);
        $lugaresPagina = array_slice($lugares, 15 * ($pagina - 1), 15);

        return $this->render('tipo_lugares/index.html.twig', [
            'form' => $form->createView(),
            'lugares' => $lugaresPagina,
            'paginaActual' => $pagina,
            'numPaginas' => $numPaginas
        ]);
    }
    /**
     * @Route("/turistico")
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     */
    public function turistico(Request $request)
    {
        $repository = $this->getDoctrine()->getRepository(Lugar::class);
        $lugares = $repository->findBy([
            'tipo' => 1
        ]);
        $form = $this->createForm(FiltrarType::class);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()){
            $repository = $this->getDoctrine()->getRepository(Lugar::class);
            $lugares = $repository->findBy([
                'municipio' => $form->getData()['municipio']
            ]);
        }

        $pagina = $request->query->get('p', 1);
        $numPaginas = ceil(count($lugares) / 15);
        $lugaresPagina = array_slice($lugares, 15 * ($pagina - 1), 15);

        return $this->render('tipo_lugares/index.html.twig', [
            'form' => $form->createView(),
            'lugares' => $lugaresPagina,
            'paginaActual' => $pagina,
            'numPaginas' => $numPaginas
        ]);
    }
    /**
     * @Route("/historico")
     */
    public function historico(Request $request)
    {
        $repository = $this->getDoctrine()->getRepository(Lugar::class);
        $lugares = $repository->findBy([
            'tipo' => 2
        ]);
        $form = $this->createForm(FiltrarType::class);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()){
            $repository = $this->getDoctrine()->getRepository(Lugar::class);
            $lugares = $repository->findBy([
                'municipio' => $form->getData()['municipio']
            ]);
        }

        $pagina = $request->query->get('p', 1);
        $numPaginas = ceil(count($lugares) / 15);
        $lugaresPagina = array_slice($lugares, 15 * ($pagina - 1), 15);

        return $this->render('tipo_lugares/index.html.twig', [
            'form' => $form->createView(),
            'lugares' => $lugaresPagina,
            'paginaActual' => $pagina,
            'numPaginas' => $numPaginas
        ]);
    }
    /**
     * @Route("/pueblo")
     */
    public function pueblo(Request $request)
    {
        $repository = $this->getDoctrine()->getRepository(Lugar::class);
        $lugares = $repository->findBy([
            'tipo' => 3
        ]);
        $form = $this->createForm(FiltrarType::class);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()){
            $repository = $this->getDoctrine()->getRepository(Lugar::class);
            $lugares = $repository->findBy([
                'municipio' => $form->getData()['municipio']
            ]);
        }

        $pagina = $request->query->get('p', 1);
        $numPaginas = ceil(count($lugares) / 15);
        $lugaresPagina = array_slice($lugares, 15 * ($pagina - 1), 15);

        return $this->render('tipo_lugares/index.html.twig', [
            'form' => $form->createView(),
            'lugares' => $lugaresPagina,
            'paginaActual' => $pagina,
            'numPaginas' => $numPaginas
        ]);
    }
}
