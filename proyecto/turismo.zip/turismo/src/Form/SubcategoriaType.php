<?php
/**
 * Created by PhpStorm.
 * User: Sam
 * Date: 06/04/2019
 * Time: 09:18 PM
 */

namespace App\Form;


use App\Entity\Subcategoria;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class SubcategoriaType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
     return $builder
         ->add('subtipo', TextType::class)
         ->add('tipoCategoria', TextType::class)
         ->getForm();
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Subcategoria::class
        ]);
    }
}