<?php
/**
 * Created by PhpStorm.
 * User: Sam
 * Date: 06/04/2019
 * Time: 02:37 PM
 */

namespace App\Form;

use App\Entity\Municipio;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ButtonType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;

class LugarType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        return $builder
            ->add('nombreLugar', TextType::class)
            ->add('nombreCalle', TextType::class)
            ->add('numeroExterior', TextType::class)
            ->add('nombreColonia', TextType::class)
            ->add('codigoPostal', TextType::class)
            ->add('nombreLocalidad', TextType::class, [
                'required' => false
            ])
            ->add('municipio', EntityType::class, [
                "class" => Municipio::class
            ])
            ->add('descripcionLugar', TextareaType::class)
            ->add('tipo', ChoiceType::class, [
                'label' => 'Tipo de lugar',
                'expanded' => true,
                'choices' => [
                    'Gastrónimico' => 0,
                    'Turístico' => 1,
                    'Histórico' => 2,
                    'Pueblo Mágico' =>3
                ]
            ])
            ->add('fotos', CollectionType::class, [
                'entry_type' => FotoType::class,
                'allow_add' => true,
                'allow_delete' => true,
                'by_reference' => false
            ])
            ->add('nuevaFoto', ButtonType::class)
            ->add('guardar', SubmitType::class)
            ->getForm();
    }
}