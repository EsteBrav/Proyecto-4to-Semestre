<?php
/**
 * Created by PhpStorm.
 * User: Sam
 * Date: 06/04/2019
 * Time: 07:03 PM
 */

namespace App\Form;


use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ButtonType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;

class CategoriaType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        return $builder
            ->add('tipo', TextType::class)
            ->add('subcategorias', CollectionType::class, [
                'entry_type' =>SubcategoriaType::class,
                'allow_add' => true,
                'allow_delete' => true,
                'by_reference' => false
            ])
            ->add('nuevaSubcategoria', ButtonType::class)
            ->add('guardar', SubmitType::class)
            ->getForm();
    }
}