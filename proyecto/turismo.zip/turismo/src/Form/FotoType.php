<?php
/**
 * Created by PhpStorm.
 * User: Sam
 * Date: 06/04/2019
 * Time: 02:26 PM
 */

namespace App\Form;


use App\Entity\Foto;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\UrlType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class FotoType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        return $builder
            ->add('nombreFoto', TextType::class)
            ->add('url', UrlType::class)
            ->getForm();
    }
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
           'data_class' => Foto::class
        ]);
    }
}