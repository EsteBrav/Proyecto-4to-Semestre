<?php
/**
 * Created by PhpStorm.
 * User: Sam
 * Date: 20/04/2019
 * Time: 10:35 PM
 */

namespace App\Form;


use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\SearchType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;

class SearchLugarType extends  AbstractController
{
    public function buildForm(FormBuilderInterface $builder, array $options){
        return $builder
            ->add('query', SearchType::class)
            ->add('search', SubmitType::class)
            ->getForm();
    }
}