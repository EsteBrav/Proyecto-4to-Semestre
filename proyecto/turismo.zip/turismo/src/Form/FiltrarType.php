<?php
/**
 * Created by PhpStorm.
 * User: Sam
 * Date: 21/04/2019
 * Time: 08:07 PM
 */

namespace App\Form;

use App\Entity\Municipio;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ButtonType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;

class FiltrarType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        return $builder
            ->add('municipio', EntityType::class, [
                "class" => Municipio::class,
                'help'=>'Escoje la ciudad donde quieras encontrar la información'
            ])
            ->add('Filtrar', ButtonType::class)
            ->getForm();
    }

}