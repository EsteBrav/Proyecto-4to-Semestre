<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190418031004 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE TBL_CATEGORIAS (id INT AUTO_INCREMENT NOT NULL, tipo VARCHAR(25) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE TBL_COMENTARIOS (id INT AUTO_INCREMENT NOT NULL, lugar_id INT DEFAULT NULL, evento_id INT DEFAULT NULL, usuario_id INT NOT NULL, fecha_comentario DATE NOT NULL, descripcion_comentario LONGTEXT DEFAULT NULL, puntuacion SMALLINT NOT NULL, INDEX IDX_9F64003B5A3803B (lugar_id), INDEX IDX_9F6400387A5F842 (evento_id), INDEX IDX_9F64003DB38439E (usuario_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE TBL_DISTRITOS (id INT AUTO_INCREMENT NOT NULL, zona_id INT NOT NULL, nombre VARCHAR(25) NOT NULL, INDEX IDX_F4250815104EA8FC (zona_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE TBL_EVENTOS (id INT AUTO_INCREMENT NOT NULL, titulo VARCHAR(100) NOT NULL, fecha_inicio DATETIME NOT NULL, fecha_final DATETIME NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE TBL_FOTOS (id INT AUTO_INCREMENT NOT NULL, lugar_id INT DEFAULT NULL, nombre_foto VARCHAR(30) NOT NULL, url VARCHAR(255) NOT NULL, INDEX IDX_268E5401B5A3803B (lugar_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE TBL_LUGARES (id INT AUTO_INCREMENT NOT NULL, municipio_id INT NOT NULL, nombre_lugar VARCHAR(100) NOT NULL, descripcion_lugar LONGTEXT NOT NULL, tipo INT NOT NULL, nombre_calle VARCHAR(30) NOT NULL, numero_exterior VARCHAR(5) NOT NULL, nombre_colonia VARCHAR(50) NOT NULL, codigo_postal VARCHAR(5) NOT NULL, nombre_localidad VARCHAR(40) DEFAULT NULL, INDEX IDX_8BC8A53658BC1BE0 (municipio_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE TBL_MUNICIPIOS (id INT AUTO_INCREMENT NOT NULL, distrito_id INT NOT NULL, nombre VARCHAR(100) NOT NULL, INDEX IDX_BF0D0AFDE557397E (distrito_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE TBL_SUBCATEGORIAS (id INT AUTO_INCREMENT NOT NULL, tipo_categoria_id INT NOT NULL, subtipo VARCHAR(25) NOT NULL, INDEX IDX_8F89743880C42E7A (tipo_categoria_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE subcategoria_evento (subcategoria_id INT NOT NULL, evento_id INT NOT NULL, INDEX IDX_228A380588D3B71A (subcategoria_id), INDEX IDX_228A380587A5F842 (evento_id), PRIMARY KEY(subcategoria_id, evento_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE TBL_USUARIOS (id INT AUTO_INCREMENT NOT NULL, uid VARCHAR(180) NOT NULL, roles LONGTEXT NOT NULL COMMENT \'(DC2Type:json)\', nombre_usuario VARCHAR(80) NOT NULL, UNIQUE INDEX UNIQ_4E06AA6C539B0606 (uid), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE TBL_ZONAS (id INT AUTO_INCREMENT NOT NULL, nombre VARCHAR(15) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('ALTER TABLE TBL_COMENTARIOS ADD CONSTRAINT FK_9F64003B5A3803B FOREIGN KEY (lugar_id) REFERENCES TBL_LUGARES (id)');
        $this->addSql('ALTER TABLE TBL_COMENTARIOS ADD CONSTRAINT FK_9F6400387A5F842 FOREIGN KEY (evento_id) REFERENCES TBL_EVENTOS (id)');
        $this->addSql('ALTER TABLE TBL_COMENTARIOS ADD CONSTRAINT FK_9F64003DB38439E FOREIGN KEY (usuario_id) REFERENCES TBL_USUARIOS (id)');
        $this->addSql('ALTER TABLE TBL_DISTRITOS ADD CONSTRAINT FK_F4250815104EA8FC FOREIGN KEY (zona_id) REFERENCES TBL_ZONAS (id)');
        $this->addSql('ALTER TABLE TBL_FOTOS ADD CONSTRAINT FK_268E5401B5A3803B FOREIGN KEY (lugar_id) REFERENCES TBL_LUGARES (id)');
        $this->addSql('ALTER TABLE TBL_LUGARES ADD CONSTRAINT FK_8BC8A53658BC1BE0 FOREIGN KEY (municipio_id) REFERENCES TBL_MUNICIPIOS (id)');
        $this->addSql('ALTER TABLE TBL_MUNICIPIOS ADD CONSTRAINT FK_BF0D0AFDE557397E FOREIGN KEY (distrito_id) REFERENCES TBL_DISTRITOS (id)');
        $this->addSql('ALTER TABLE TBL_SUBCATEGORIAS ADD CONSTRAINT FK_8F89743880C42E7A FOREIGN KEY (tipo_categoria_id) REFERENCES TBL_CATEGORIAS (id)');
        $this->addSql('ALTER TABLE subcategoria_evento ADD CONSTRAINT FK_228A380588D3B71A FOREIGN KEY (subcategoria_id) REFERENCES TBL_SUBCATEGORIAS (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE subcategoria_evento ADD CONSTRAINT FK_228A380587A5F842 FOREIGN KEY (evento_id) REFERENCES TBL_EVENTOS (id) ON DELETE CASCADE');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE TBL_SUBCATEGORIAS DROP FOREIGN KEY FK_8F89743880C42E7A');
        $this->addSql('ALTER TABLE TBL_MUNICIPIOS DROP FOREIGN KEY FK_BF0D0AFDE557397E');
        $this->addSql('ALTER TABLE TBL_COMENTARIOS DROP FOREIGN KEY FK_9F6400387A5F842');
        $this->addSql('ALTER TABLE subcategoria_evento DROP FOREIGN KEY FK_228A380587A5F842');
        $this->addSql('ALTER TABLE TBL_COMENTARIOS DROP FOREIGN KEY FK_9F64003B5A3803B');
        $this->addSql('ALTER TABLE TBL_FOTOS DROP FOREIGN KEY FK_268E5401B5A3803B');
        $this->addSql('ALTER TABLE TBL_LUGARES DROP FOREIGN KEY FK_8BC8A53658BC1BE0');
        $this->addSql('ALTER TABLE subcategoria_evento DROP FOREIGN KEY FK_228A380588D3B71A');
        $this->addSql('ALTER TABLE TBL_COMENTARIOS DROP FOREIGN KEY FK_9F64003DB38439E');
        $this->addSql('ALTER TABLE TBL_DISTRITOS DROP FOREIGN KEY FK_F4250815104EA8FC');
        $this->addSql('DROP TABLE TBL_CATEGORIAS');
        $this->addSql('DROP TABLE TBL_COMENTARIOS');
        $this->addSql('DROP TABLE TBL_DISTRITOS');
        $this->addSql('DROP TABLE TBL_EVENTOS');
        $this->addSql('DROP TABLE TBL_FOTOS');
        $this->addSql('DROP TABLE TBL_LUGARES');
        $this->addSql('DROP TABLE TBL_MUNICIPIOS');
        $this->addSql('DROP TABLE TBL_SUBCATEGORIAS');
        $this->addSql('DROP TABLE subcategoria_evento');
        $this->addSql('DROP TABLE TBL_USUARIOS');
        $this->addSql('DROP TABLE TBL_ZONAS');
    }
}
